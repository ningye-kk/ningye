#include <iostream>
#include <algorithm>
#include <array>
#include <iterator>
#include <vector>
#include <fstream>
#include <list>
#include <cstring>
#include <iomanip>

using namespace std;

int main()
{
    int a[10];

    for(int i=0;i<10;i++)
        cin>>a[i];

    for(int i=0;i<10;i++)
    {
        int j;
        int temp=a[i];
        for(j=i;j>0&&temp>a[j-1];j--)
            a[j]=a[j-1];
        a[j]=temp;
    }

    for(int i=0;i<10;i++)
        cout<<a[i]<<" ";
    cout<<endl;
    return 0;
}
