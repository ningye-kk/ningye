#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char str[100];
    cin.getline(str,100);

    char searchStr[10];
    cin.getline(searchStr,10);

    char* searchPtr=strstr(str,searchStr);
    if(searchPtr)
    {
        int i=0;
        while(str[i]!=*searchPtr)
            i++;
        for(;str[i]!='\0';i++)
            cout<<str[i];
        cout<<endl;
    }
    else
    {
        cout<<"NO"<<endl;
    }
    return 0;
}
