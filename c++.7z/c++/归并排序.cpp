#include <iostream>

using namespace std;

const int maxn = 100;

void merge(int A[],int L1,int R1,int L2,int R2){
    int i = L1,j = L2;
    int temp[maxn],index = 0;
    while(i <= R1 && j <= R2){
        if(A[i] <= A[j]){
            temp[index++] = A[i++];
        }
        else{
            temp[index++] = A[j++];
        }
    }

    while(i <= R1) temp[index++] = A[i++];
    while(j <= R2) temp[index++] = A[j++];
    for(i = 0;i < index;i++){
        A[L1+i] = temp[i];
    }
}

void mergeSort(int A[],int L,int R){
    if(L < R){
        int mid = L + (R - L)/2;
        mergeSort(A,L,mid);
        mergeSort(A,mid+1,R);
        merge(A,L,mid,mid+1,R);
    }
}

int main(){
    int a[maxn];
    int n;
    cin>>n;
    for(int i = 0;i < n;i++){
        cin>>a[i];
    }
    mergeSort(a,0,n-1);
    for(int i = 0;i < n;i++){
        cout<<a[i]<<" ";
    }
    return 0;
}
