#include <iostream>
#include <array>
#include <algorithm>

using namespace std;

int main()
{
    array<int,20>  a;
    array<int,20>  b;
    for(int i=0;i<20;i++)
    {
        cin>>a[i];
    }

    sort(a.begin(),a.end());
    int len=unique(a.begin(),a.begin()+20)-a.begin();

    copy(a.begin(),unique(a.begin(),a.begin()+20),b.begin());

    for(int i=0;i<len;i++)
    {
        cout<<b[i]<<" ";
    }
    return 0;
}
