#include <iostream>
#include <iterator>

using namespace std;

int main()
{
    cout<<"Enter two numbers:";

    istream_iterator<int> input(cin);
    int number1=*input;
    input++;
    int number2=*input;

    ostream_iterator<int> output(cout);

    cout<<"The sum is:";
    *output=number1+number2;
    cout<<endl;
    return 0;
}
