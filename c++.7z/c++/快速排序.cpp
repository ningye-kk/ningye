#include <iostream>
#include <array>

using namespace std;

const int maxN=10;
array<int,maxN> a;

int partition1(int low,int high)
{
    int pivot=a[low];
    while(low<high)
    {
        while(low<high&&a[high]>=pivot) --high;
        if(low<high)
        {
            a[low]=a[high];
        }

        while(low<high&&a[low]<=pivot) ++low;
        if(low<high)
        {
            a[high]=a[low];
        }
    }
    a[low]=pivot;
    return low;
}

void quick_sort(int low,int high)
{
    if(low<high)
    {
        int place;
        place=partition1(low,high);
        quick_sort(low,place-1);
        quick_sort(place+1,high);
    }
}

int main()
{
    for(int i=0;i<maxN;i++)
    {
        cin>>a[i];
    }

    quick_sort(0,maxN-1);

    for(int i=0;i<maxN;i++)
    {
        cout<<a[i]<<" ";
    }

    return 0;
}
