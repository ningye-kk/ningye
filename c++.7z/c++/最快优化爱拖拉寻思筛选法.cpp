#include <iostream>
#include <bitset>
#include <cmath>

using namespace std;

bitset<1024> a;

void fun(int m)
{
    for(int i=2;i<sqrt((double)m);i++)
    {
        if(a[i]==0)
        {
            for(int j=i*i;j<=m;j+=i)
            {
                a[j]=1;
            }
        }
    }

    for(int i=2;i<=1023;i++)
    {
        if(a[i]==0)
            cout<<i<<" ";
    }
    cout<<endl;
}


int main()
{
    fun(1023);
    return 0;
}
