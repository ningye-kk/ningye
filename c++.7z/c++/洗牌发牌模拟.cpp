#include <iostream>
#include <string>
#include <array>
#include <cstdlib>
#include <ctime>
#include <iomanip>

using namespace std;

struct Card
{
    string face;
    string suit;
};

class DeckOfCards
{
public:
    static const int num=52;
    static const int faces=13;
    static const int suits=4;

    DeckOfCards()
    {
        static string face[faces]={"Ace","Deuce","Three","Four","Five","Six",
            "Seven","Eight","Nine","Ten","Jack","Queen","King"};

        static string suit[suits]={"Hearts","Diamonds","Clubs","Spades"};

        for(int i=0;i<deck.size();i++)
        {
            deck[i].face=face[i%faces];
            deck[i].suit=suit[i/faces];
        }
        srand(static_cast<size_t>(time(0)));
    }

    void shuffle()
    {
        for(int i=0;i<deck.size();i++)
        {
            int j=rand()%num;
            Card temp=deck[i];
            deck[i]=deck[j];
            deck[j]=temp;
        }
    }

    void print() const
    {
        for(int i=0;i<deck.size();i++)
        {
            cout<<right<<setw(5)<<deck[i].face<<" of "
                <<left<<setw(8)<<deck[i].suit
                <<((i+1)%2?'\t':'\n');
        }
    }

private:
    array<Card,num> deck;
};

int main()
{
    DeckOfCards deckofcards;
    deckofcards.shuffle();
    deckofcards.print();

    return 0;
}
