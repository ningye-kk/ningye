#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char str[100];
    cin.getline(str,100);

    char searchStr[10];
    cin.getline(searchStr,10);

    char* searchPtr=&str[0];

    int sum=0;
    while(searchPtr)
    {
        searchPtr=strstr(searchPtr,searchStr);
        if(searchPtr)
            sum++;
        else
        {
            break;
        }
        searchPtr++;
    }

    cout<<sum<<endl;

    return 0;
}
