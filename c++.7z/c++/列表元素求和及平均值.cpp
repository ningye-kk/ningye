#include <iostream>
#include <vector>
#include <algorithm>
#include <iterator>
#include <ctime>
//#include <cstdlib>

using namespace std;

struct Node
{
    int c;
    Node* next;
};

bool compare(Node a,Node b)
{
    return a.c<b.c;
}

void initial(vector<Node>& a)
{
    Node b;
    srand(static_cast<unsigned int> (time(0)));
    for(int i=0;i<a.size();i++)
    {
        b.c=rand()%100;
        b.next=nullptr;
        a[i]=b;
    }

    sort(a.begin(),a.end(),compare);

    for(int i=0;i<a.size()-1;i++)
    {
        a[i].next=&a[i+1];
    }

    int sum=0;

    for(int i=0;i<a.size();i++)
    {
        cout<<a[i].c<<" ";
        sum+=a[i].c;
    }

    cout<<endl;
    cout<<"��Ϊ"<<sum<<endl;
    cout<<"ƽ��ֵΪ"<<sum/a.size()<<endl;

}

int main()
{
    vector<Node> a(10);

    initial(a);

    return 0;
}
