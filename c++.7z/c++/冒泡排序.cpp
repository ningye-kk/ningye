#include <iostream>
#include <array>

using namespace std;

const int maxN=10;

void bubbleSort(array<int,maxN> &a)
{
    bool flag;
    for(int i=maxN-1;i>0;i--)
    {
        flag=false;
        for(int j=0;j<i;j++)
        {
            if(a[j]>a[j+1])
            {
                int temp;
                temp=a[j];
                a[j]=a[j+1];
                a[j+1]=temp;
                flag=true;
            }
        }
        if(flag==false)
            break;
    }
}

int main()
{
    array<int,maxN> a;
    for(int i=0;i<maxN;i++)
        cin>>a[i];

    bubbleSort(a);

    for(int i=0;i<maxN;i++)
        cout<<a[i]<<" ";
    cout<<endl;

    return 0;
}
