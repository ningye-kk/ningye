#include <iostream>
#include <cstring>
#include <cstdlib>
#include <ctime>

using namespace std;

int main()
{
    const char* article[5]={"the","a","one","some","any"};
    const char* noun[5]={"boy","girl","dog","town","car"};
    const char* verb[5]={"drove","jumped","ran","walked","skipped"};
    const char* preposition[5]={"to","from","over","under","on"};
    char sentence[100];

    char a;
    while(cin>>a)
    {
        srand(static_cast<size_t> (time(0)));
        memset(sentence,0,sizeof(sentence));
        if(a=='Y'||a=='y')
        {
            int i=rand()%5;
            strcpy(sentence,article[i]);
            sentence[strlen(sentence)]=' ';
            i=rand()%5;
            strcat(sentence,noun[i]);
            sentence[strlen(sentence)]=' ';
            i=rand()%5;
            strcat(sentence,verb[i]);
            sentence[strlen(sentence)]=' ';
            i=rand()%5;
            strcat(sentence,preposition[i]);
            sentence[strlen(sentence)]=' ';
            i=rand()%5;
            strcat(sentence,article[i]);
            sentence[strlen(sentence)]=' ';
            i=rand()%5;
            strcat(sentence,noun[i]);
            sentence[strlen(sentence)]=' ';
            cout<<sentence<<endl;
        }
        else
        {
            break;
        }
    }
    return 0;
}
