#include <iostream>
#include <iterator>
#include <algorithm>
#include <string>
#include <cctype>

using namespace std;

bool testPalindrome()
{
    string out,s;
    getline(cin,s);
    int i=0;
 /*   while(s[i])
    {
        if(!ispunct(s[i]))
        {
            out+=s[i];
        }
        ++i;
    }
*/
    copy_if(s.begin(),s.end(),back_inserter(out),[](char c){return !ispunct(c);});
    string temp=out;
    reverse(out.begin(),out.end());

    if(temp==out)
        return true;
    else
        return false;
}

int main()
{

    if(testPalindrome())
        cout<<"YES"<<endl;
    else
        cout<<"NO"<<endl;
    return 0;

}
