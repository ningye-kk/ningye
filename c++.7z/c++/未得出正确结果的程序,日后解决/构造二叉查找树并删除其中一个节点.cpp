#include <iostream>
#include <vector>

using namespace std;

template <typename T>
vector<T> vec;

template <typename T>
class BSTNode
{
public:
    T data;
    BSTNode* lchild;
    BSTNode* rchild;
    BSTNode* parent;
};

template <typename T>
class BStree
{
public:
    BSTNode<T>* root;

    BStree():root(nullptr){}

    BStree(vector<T> a)
    {
        root=new BSTNode<T>;
        root->data=a[0];
        root->lchild=root->rchild=nullptr;
        //insertNode(root);
        for(int i=1;i<a.size();i++)
        {
            BSTNode<T>* b=new BSTNode<T>;
            b->data=a[i];
            b->lchild=b->rchild=nullptr;

            insertNode(b);
        }
    }

    ~BStree(){}

    void insertNode(BSTNode<T>* z)
    {
        BSTNode<T>* parent=nullptr;
        BSTNode<T>* temp=root;

        while(temp!=nullptr)
        {
            parent=temp;
            if(z->data>temp->data)
                temp=temp->rchild;
            else
                temp=temp->lchild;
        }

        if(parent==nullptr)
            root=z;
        else
        {
            if(z->data>parent->data)
                parent->rchild=z;
            else
                parent->lchild=z;
        }
    }

    BSTNode<T>* successor(BSTNode<T>* z)
    {
        if(z->rchild==nullptr)
        {
            if(z->parent->lchild==z)
                return z->parent;
            else
            {
                BSTNode<T>* p=z->parent->parent;
                while(p->lchild==nullptr)
                {
                    p=p->parent;
                }
                return p;
            }
        }
        else
        {
            BSTNode<T>* p=z->rchild;
            while(p->lchild==nullptr&&p->rchild!=nullptr)
            {
                p=p->rchild;
            }

            if(p->lchild!=nullptr)
                return p->lchild;
            else
                return p;
        }
    }

    BSTNode<T>*  delete1(BSTNode<T>* z)
    {
        BSTNode<T>* x=nullptr;
        BSTNode<T>* y=nullptr;

        if((z->lchild==nullptr)||(z->rchild==nullptr))
            y=z;
        else
            y=successor(z);

        if(y->lchild!=nullptr)
            x=y->lchild;
        if(y->rchild!=nullptr)
            x=y->rchild;

        if(x!=nullptr)
            x->parent=y->parent;

        if(y->parent==nullptr)
            root=x;
        else
        {
            if(y->parent->lchild==y)
                y->parent->lchild=x;
            else
                y->parent->rchild=x;
        }

        if(y!=z)
            z->data=y->data;

        return y;
    }
};

int main()
{
    int n;
    cin>>n;

    vector<int> vec(n);

    for(int i=0;i<n;i++)
    {
        cin>>vec[i];
    }

    BStree<int> tree(vec);

    tree.delete1(tree.root);

    cout<<tree.root->data<<endl;

    return 0;
}
