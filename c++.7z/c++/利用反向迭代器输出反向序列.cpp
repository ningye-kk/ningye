#include <iostream>
#include <string>

using namespace std;

int main()
{
    string str;
    cin>>str;


    for(auto it=str.crbegin();it<str.crend();it++)
        cout<<*it;

    cout<<endl;
    return 0;
}
