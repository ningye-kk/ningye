#include <iostream>
#include <iomanip>

using namespace std;

class Point
{
    friend istream& operator>>(istream&,Point&);
    friend ostream& operator<<(ostream&,const Point&);
private:
    int xCoordinate,yCoordinate;
};

istream& operator>>(istream& in,Point& p)
{
    in.ignore();
    in>>p.xCoordinate;
    in.ignore();
    in>>p.yCoordinate;

    if(in.fail())
    {
        cerr<<"mistake data"<<endl;
        in.clear(istream::failbit);
    }
    return in;
}

ostream& operator<<(ostream& out,const Point& p)
{
    out<<'('<<p.xCoordinate<<','<<p.yCoordinate<<')'<<endl;
    return out;
}

int main()
{
    Point p;
    cin>>p;
    cout<<p;
    return 0;
}
