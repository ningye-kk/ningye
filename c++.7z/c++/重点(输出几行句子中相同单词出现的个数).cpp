#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;

int main()
{
    int count[100]={0};
    char words[100][20]={""};
    char text[2][100];
    const char* delim=",.! ?";

    for(int i=0;i<2;i++)
    {
        cin.getline(&text[i][0],100);

        char* p=strtok(&text[i][0],delim);

        while(p!=NULL)
        {
            int j;
            for(j=0;strcmp(&words[j][0],p)!=0&&words[j][0]!='\0';j++);
            count[j]++;
            if(!words[j][0])
            {
                strcpy(&words[j][0],p);
            }
            p=strtok(NULL,delim);
        }
    }

    cout<<endl;

    cout<<setw(10)<<"words"<<setw(10)<<"����"<<endl;

    for(int k=0;words[k][0]!='\0'&&k<100;k++)
    {
        cout<<setw(10)<<&words[k][0]<<setw(10)<<count[k]<<endl;
    }

    cout<<endl;
    return 0;
}
