#include <iostream>
#include <array>
#include <algorithm>
#include <vector>
#include <iterator>

using namespace std;

int main()
{
    vector<int>  b;
    array<int,20>  a;
    for(int i=0;i<20;i++)
    {
        cin>>a[i];
    }
    sort(a.begin(),a.end());
    unique_copy(a.begin(),a.end(),back_inserter(b));

    for(int i=0;i<b.size();i++)
        cout<<b[i]<<" ";
    cout<<endl;
    return 0;
}
