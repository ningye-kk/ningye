#include <iostream>
#include <stack>
#include <cctype>
#include <stack>

using namespace std;

int main()
{
    string s;
    getline(cin,s);

    stack<char> s1;

    int i=0;
    while(s[i]!='\0')
    {
        s1.push(s[i]);
        i++;
    }

    bool flag=false;
    int j=0;
    while(!s1.empty())
    {
        if(s1.top()==s[j++])
        {
            flag=true;
        }
        else
        {
            flag=false;
            break;
        }
        s1.pop();
    }

    if(flag==true)
        cout<<"YES"<<endl;
    else
        cout<<"NO"<<endl;
    return 0;
}
