#include <iostream>
#include <stack>

using namespace std;

int main()
{
    stack<char>  s;

    char c;
    while(cin>>c)
    {
        s.push(c);
    }

    while(!s.empty())
    {
        cout<<s.top();
        s.pop();
    }

    return 0;
}
