#include <iostream>
#include <iterator>
#include <algorithm>
#include <list>
#include <string>
#include <cstring>

using namespace std;

int main()
{
    list<string>  a;
    list<string>  b;
    list<string>  c;
    a.push_back("li");
    a.push_back("nan");
    a.push_back("yang");

    b.push_back("bing");
    b.push_back("luo");

    merge(a.begin(),a.end(),b.begin(),b.end(),ostream_iterator<string> (cout," "));
}
