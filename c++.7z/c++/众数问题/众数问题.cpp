#include <iostream>
#include <fstream>

using namespace std;

void swap1(int &a,int &b){
    int c;
    c = a;
    a = b;
    b = c;
}

//��һ�����ʵ��������黮��Ϊ������,����ѡ��������ֵ
void partition1(int* a,int l,int r,int &l1,int &r1){
    int key = a[l];
    l1 = l - 1;
    r1 = r + 1;
    int p = l;
    while(p < r1){
        if(a[p] > key){
            swap1(a[--r1],a[p]);
        }
        else if(a[p] < key){
            swap1(a[++l1],a[p++]);
        }
        else{
            p++;
        }
    }
}

//֮����mode����
void mode(int* a,int l,int r,int &largest,int &element){
    int x,y;
    largest = 0;
    element = a[l];
    partition1(a,l,r,x,y);
    if(largest < y-x-1){
        largest = y-x-1;
        element = a[y-1];
    }
    if(largest < x - l + 1){
        mode(a,l,x,largest,element);
    }
    if(largest < r - y + 1){
        mode(a,y,r,largest,element);
    }
}



int main(){
    ifstream in("input.txt");
    ofstream out("output.txt");
    int a[100];
    int n,i = 0,x,y;
    in>>n; // ���鳤��
    while(!in.eof()){
        in>>a[i];
        i++;
    }
    mode(a,0,i-1,x,y);
    out<<y<<endl;
    out<<x<<endl;
    return 0;
}
