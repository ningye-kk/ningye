#include <iostream>
#include <stack>
#include <string>

using namespace std;

bool isOperator(char c)
{
    switch(c)
    {
        case '+':
        case '-':
        case '*':
        case '/':return true;
        default:return false;
    }
}

double count(double a,char c,double b)
{
    switch(c)
    {
        case '+':return a+b;
        case '-':return a-b;
        case '*':return a*b;
        case '/':return a/b;
    }
}

bool precedence(char a,char b)  //aΪջ��Ԫ��
{
    if(b=='*'||b=='/')
    {
        switch(a)
        {
            case '*':
            case '/':return true;
            default:return false;
        }
    }
    else
    {
        return true;
    }
}

void convertToPostfix(const string& str)
{
    stack<char> sop;
    stack<double> s;
    int i=0;
    double a,b;
    char c;

    while(str[i]!='\0')
    {
        if(str[i]=='(')
        {
            sop.push(str[i]);
            ++i;
        }
        else if(str[i]>='0'&&str[i]<='9')  //�������ֲ�����
        {
            if(str[i-1]>='0'&&str[i-1]<='9')
            {
                 a=s.top()*10+str[i]-48;
                 s.pop();
                 s.push(a);
            }
            else
            {
                s.push(str[i]-48);
            }
            ++i;
        }
        else if(isOperator(str[i]))
        {
            if(!sop.empty()&&sop.top()!='(')
            {
                switch(precedence(sop.top(),str[i]))
                {
                    case false:sop.push(str[i]);
                                ++i;
                                break;
                    case true:c=sop.top();
                               sop.pop();
                               b=s.top();
                               s.pop();
                               a=s.top();
                               s.pop();
                               s.push(count(a,c,b));
                               break;
                }
            }
            else
            {
                sop.push(str[i]);
                ++i;
            }
        }
        else if(str[i]==')')
        {
            if(sop.top()!='(')
            {
                c=sop.top();
                sop.pop();
                b=s.top();
                s.pop();
                a=s.top();
                s.pop();
                s.push(count(a,c,b));
            }
            else
            {
                sop.pop();
                ++i;
            }
        }
    }

    while(!sop.empty())
    {
        c=sop.top();
        sop.pop();
        b=s.top();
        s.pop();
        a=s.top();
        s.pop();
        s.push(count(a,c,b));
    }
    cout<<"�����:"<<s.top()<<endl;
}

int main()
{
    string str;
    getline(cin,str);

    convertToPostfix(str);
    return 0;
}
