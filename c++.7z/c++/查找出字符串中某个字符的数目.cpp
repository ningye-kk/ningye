#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char str[100];
    cin.getline(str,100);

    char searchChr;
    cin>>searchChr;

    char* searchPtr=&str[0];

    int sum=0;
    while(searchPtr)
    {
        searchPtr=strchr(searchPtr,searchChr);
        if(searchPtr)
            sum++;
        else
        {
            break;
        }
        searchPtr++;
    }

    cout<<sum<<endl;

    return 0;
}
