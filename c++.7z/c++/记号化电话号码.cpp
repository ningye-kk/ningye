#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char a[100];
    cin.getline(a,100);

    char *p,*q;
    const char* delim="()-";
    p=strtok(a,delim);
    cout<<"����Ϊ:"<<p<<endl;
    p=strtok(NULL,delim);
    q=strtok(NULL,delim);
    char* t=new char[sizeof(p)+sizeof(q)+1];
    strcpy(t,p);
    strcat(t,q);
    cout<<"�绰����Ϊ:"<<t<<endl;
    return 0;
}
