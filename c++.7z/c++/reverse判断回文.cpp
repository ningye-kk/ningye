#include <iostream>
#include <iterator>
#include <algorithm>
#include <string>

using namespace std;

bool testPalindrome(string s)
{
    string temp=s;
    reverse(s.begin(),s.end());
    if(s==temp)
        return true;
    else
        return false;
}

int main()
{
    string s{"able was i ere i saw elba"};
    bool flag;
    flag=testPalindrome(s);
    if(flag==true)
        cout<<"��"<<endl;
    else
        cout<<"��"<<endl;
    return 0;

}
