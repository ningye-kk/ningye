#include <iostream>
#include <cstring>

using namespace std;

char b[]={"ay"};

void printLatinWord(char* a)
{
    char temp=a[0];
    int len=strlen(a);

    for(int i=1;i<len;i++)
        a[i-1]=a[i];
    a[len-1]=temp;

    char* t=new char[sizeof(a)+sizeof(b)+1];
    strcpy(t,a);
    strcat(t,b);

    cout<<t<<" ";
    delete t;
}

int main()
{
    char a[100];
    cin.getline(a,100);

    char* p;

    const char* delim=" ";

    p=strtok(a,delim);
    printLatinWord(p);
    while(p!=NULL)
    {
        p=strtok(NULL,delim);
        printLatinWord(p);
    }
    cout<<endl;
    return 0;
}
