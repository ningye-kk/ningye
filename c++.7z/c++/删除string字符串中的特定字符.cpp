#include <iostream>
#include <string>

using namespace std;

int main()
{
    string str;
    cin>>str;

    for(int i=0;i<str.size()-1;i++)
    {
        if((str[i]=='b'&&str[i+1]=='y')||(str[i]=='B'&&str[i+1]=='Y'))
        {
            str.erase(i,2);
        }
    }

    cout<<str;

    return 0;
}
