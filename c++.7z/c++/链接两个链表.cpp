#include <iostream>
#include <vector>

using namespace std;

struct Node
{
    char c;
    Node* next;
};

void initial(vector<Node>& a)
{
    for(int i=0;i<a.size()-1;i++)
    {
        a[i].next=&a[i+1];
    }

    a[a.size()-1].next=nullptr;

    for(int i=0;i<a.size();i++)
    {
        cin>>a[i].c;
    }
    cout<<endl;
}

void concatenate(vector<Node>& a,vector<Node>& b)
{
    a[a.size()-1].next=&b[0];
}

int main()
{
    vector<Node> a(10);
    vector<Node> b(10);

    initial(a);
    initial(b);
    concatenate(a,b);

    Node* it=&a[0];
    while(it)
    {
        cout<<it->c<<" ";
        it=it->next;
    }
    return 0;
}
