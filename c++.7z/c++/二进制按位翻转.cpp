#include <iostream>
#include <algorithm>

using namespace std;

unsigned int bit_reverse(unsigned int x)
{
    int value=0;
    int i;
    int top=32;
    for(i=0;i<top;i++)
    {
        if(x&(1<<i))
        {
            value|=(1<<(top-1-i));
        }
    }
    return value;
}

int main()
{
    char str[33];
    int data;
    cin>>data;
    cout<<itoa(data,str,2)<<endl;
    cout<<bit_reverse(data)<<endl;
    cout<<itoa(bit_reverse(data),str,2)<<endl;
    return 0;
}
