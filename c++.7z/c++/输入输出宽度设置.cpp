#include <iostream>

using namespace std;

int main()
{
    int width=4;
    char sentence[10];

    cin.width(5);

    while(cin>>sentence)
    {
        cout.width(width++);
        cout<<sentence<<endl;
        cin.width(5);
    }
    return 0;
}
