#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>
#include <fstream>

using namespace std;

int main()
{
    ifstream in_file("a.txt");
    ofstream out_file("b.txt");
    istream_iterator<int> a(in_file);
    istream_iterator<int> eof;
    vector<int> b;

    copy(a,eof,back_inserter(b));
    sort(b.begin(),b.end());

    ostream_iterator<int> c(out_file," ");
    copy(b.begin(),b.end(),c);
    return 0;
}
