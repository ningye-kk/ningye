#include <iostream>
#include <string>

using namespace std;

int main()
{
    string s{"abcdefghijklmnopqrstuvwxyz{"};

    int spaceNum=13;

    for(int i=0;i<14;i++)
    {
        for(int j=0;j<spaceNum;j++)
            cout<<" ";

        int k=i;
        for(int j=0;j<2*i+1;j++)
        {
            if(j<i+1)
            {
                cout<<s[k++];
                continue;
            }
            if(j==i+1)
                k-=2;
            cout<<s[k--];
        }
        spaceNum--;
        cout<<endl;
    }

    return 0;
}
