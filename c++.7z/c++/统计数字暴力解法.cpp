#include<iostream>
using namespace std;

void count_num(int n)
{
	int count[10]={0};
	for (int i=1;i<=n;i++)
	{
		int t=i;

		while(t)
		{
			count[t%10]++;//�����λ���ִ���
			t/=10;//�������λ
		}
	}
	for(int i=0;i<10;i++)
	{

		cout<<"present num of  "<<i<<"   is   "<<count[i]<<'\n';
	}

}


int main()
{
    int n;
    cin>>n;
	count_num(n);

	return 0;
}
