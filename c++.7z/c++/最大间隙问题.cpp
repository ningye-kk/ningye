#include <iostream>

using namespace std;

template <class T>
int min1(int n,T* x){
    int k = 0;
    T tmp = x[1];
    for(int i = 0;i < n;i++){
        if(tmp > x[i]){
            tmp = x[i];
            k = i;
        }
    }
    return k;
}

template <class T>
int max1(int n,T* x){
    int k = 0;
    T tmp = x[1];
    for(int i = 0;i < n;i++){
        if(tmp < x[i]){
            tmp = x[i];
            k = i;
        }
    }
    return k;
}

double maxgap(int n,double* x){
    double minx = x[min1(n,x)],maxx = x[max1(n,x)];
    int* count = new int[n+1];
    double* low = new double[n+1];
    double* high = new double[n+1];

    for(int i = 0;i < n - 1;i++){
        count[i] = 0;
        low[i] = maxx;
        high[i] = minx;
    }

    for(int i = 0;i < n;i++){
        int bucket = int((n-1)*(x[i] - minx) / (maxx - minx));
        count[bucket]++;
        if(x[i] < low[bucket]) low[bucket] = x[i];
        if(x[i] > high[bucket]) high[bucket] = x[i];
    }

    double tmp = 0,left = high[0];
    for(int i = 1;i < n - 1;i++){
        if(count[i]){
            double thisgap = low[i] - left;
            if(thisgap > tmp) tmp = thisgap;
            left = high[i];
        }
    }
    return tmp;
}

int main(){
    int n;
    cin>>n;
    double a[n];
    for(int i = 0;i < n;i++){
        cin>>a[i];
    }
    int tmp = maxgap(n,a);
    cout<<tmp<<endl;
    return 0;
}
