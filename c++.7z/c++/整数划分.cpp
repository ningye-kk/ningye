#include <iostream>

using namespace std;

int f(int n,int m){
    if(n == 1 || m == 1){
        return 1;
    }
    else if(n == m){
        return 1 + f(n,m-1);
    }
    else if(n < m){
        return f(n,n);
    }
    else{
        return f(n,m-1) + f(n-m,m);
    }
}

int main(){
    cout<<f(6,6)<<endl;
    return 0;
}
