#include <iostream>
#include <iomanip>

using namespace std;

class Complex
{
    friend istream& operator>>(istream&,Complex&);
    friend ostream& operator<<(ostream&,const Complex&);
private:
    int real,imaginary;
};

istream& operator>>(istream& in,Complex& c)
{
    in>>c.real;
    if(in.fail())
    {
        cerr<<"wrong real value"<<endl;
        in.clear(istream::failbit);
    }

    char ch;
    in>>ch;
    in>>c.imaginary;
    if(ch=='-')
        c.imaginary=-1*c.imaginary;
    if(in.fail())
    {
        cerr<<"wrong imaginary value"<<endl;
        in.clear(istream::failbit);
    }
    return in;
}

ostream& operator<<(ostream& out,const Complex& c)
{
    cout<<c.real;
    if(c.imaginary>=0)
        cout<<'+'<<c.imaginary<<'i'<<endl;
    else
        cout<<c.imaginary<<'i'<<endl;
    return out;
}

int main()
{
    Complex c;
    cin>>c;
    cout<<c;
    return 0;
}
