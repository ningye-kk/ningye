#include <iostream>
#include <string>

using namespace std;

//�������
int f(int m,int n){
    int sum = 1,sum1 = 1;
    for(int i = 1;i <= n;i++){
        sum *= i;
    }
    for(int i = m;i > (m - n);i--){
        sum1 *= i;
    }
    return sum1 / sum;
}

int main(){
    int a[10],k,len,sum = 0;
    string str;
    int i ,j;
    cin>>k;
    while(k--){
        cin>>str;
        len = str.length();
        for(i = 1;i < len;i++){
            sum += f(26,i);
        }
        for(i = 0;i < len;i++){
            a[i] = str[i] - 'a';
        }
        int temp = 1;
        for(i = len;i > 0;i--){
            for(j = temp;j < a[len-i];j++){
                sum += f(26-j,i-1);
            }
            temp = a[len-i]+1;
        }
        cout<<sum+1<<endl;
    }
    return 0;
}
