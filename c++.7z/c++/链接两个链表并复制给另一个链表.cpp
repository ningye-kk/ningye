#include <iostream>
#include <vector>
#include <algorithm>
#include <iterator>

using namespace std;

struct Node
{
    int c;
    Node* next;
};

bool compare(Node a,Node b)
{
    return a.c<b.c;
}

void initial(vector<Node>& a)
{
    for(int i=0;i<a.size()-1;i++)
    {
        a[i].next=&a[i+1];
    }

    a[a.size()-1].next=nullptr;

    for(int i=0;i<a.size();i++)
    {
        cin>>a[i].c;
    }
    cout<<endl;
}

void merge1(vector<Node>& a,vector<Node>& b,vector<Node>& c)
{
    copy(a.begin(),a.end(),c.begin());
    copy(b.begin(),b.end(),&c[a.size()]);
    c[a.size()-1].next=&c[a.size()];

    sort(c.begin(),c.end(),compare);

    for(int i=0;i<c.size();i++)
        cout<<c[i].c<<" ";
    cout<<endl;
}

int main()
{
    vector<Node> a(10);
    vector<Node> b(10);
    vector<Node> c(20);

    initial(a);
    sort(a.begin(),a.end(),compare);
    initial(b);
    sort(b.begin(),b.end(),compare);

    merge1(a,b,c);

    return 0;
}
