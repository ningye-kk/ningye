#include <iostream>
#include <string>

using namespace std;

bool huiWen(string s)
{
    bool flag=false;
    for(int i=0;i<s.size();i++)
    {
        if(s[i]==s[s.size()-i-1])
        {
            flag=true;
        }
        else
        {
            flag=false;
            break;
        }
    }
    return flag;
}

int main()
{
    int n;
    cin>>n;
    string *str=new string[n];

    int sum=0;

    for(int i=0;i<n;i++)
    {
        cin>>str[i];
        if(huiWen(str[i]))
            sum++;
    }

    cout<<"���ĵ�����Ϊ:"<<sum<<endl;

    delete str;
    return 0;
}
