#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char str[20];
    cin.getline(str,20);

    const char* delim="/";
    const char* months[13]={"","Jan","Feb","March","April","May"
        ,"June","July","Agust","Sep","Oct","Nov","Dec"};

    char* month=strtok(str,delim);

    char* day=strtok(NULL,delim);

    char* year=strtok(NULL,delim);

    cout<<months[atoi(month)]<<" "<<day<<","<<year<<endl;

    return 0;
}

