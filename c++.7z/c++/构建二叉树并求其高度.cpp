#include <iostream>
#include <vector>

using namespace std;

struct Node
{
    int data;
    Node* lchild;
    Node* rchild;
};

vector<int> pre;
vector<int> in;

Node* createTree(int preL,int preR,int inL,int inR)
{
    if(preL>preR)
        return nullptr;
    Node* root=new Node;
    root->data=pre[preL];
    int i;
    for(i=inL;i<=inR;i++)
    {
        if(pre[preL]==in[i])
        {
            break;
        }
    }

    int llen=i-inL;

    root->lchild=createTree(preL+1,preL+llen,inL,i-1);
    root->rchild=createTree(preL+llen+1,preR,i+1,inR);

    return root;
}

int depth(Node* root)
{
     if(root==nullptr)
        return 0;
     else
     {
         int llen=depth(root->lchild);
         int rlen=depth(root->rchild);
         return (llen>rlen?llen:rlen)+1;
     }
}

int main()
{
    int a,b,n;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>a;
        pre.push_back(a);
    }

    for(int i=0;i<n;i++)
    {
        cin>>b;
        in.push_back(b);
    }

    Node* root=createTree(0,n-1,0,n-1);

    int len=depth(root);

    cout<<"�������߶�Ϊ:"<<len<<endl;

    return 0;
}
