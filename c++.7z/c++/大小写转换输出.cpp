#include <iostream>
#include <algorithm>
#include <cstring>

using namespace std;

int main()
{
    char str[100];
    cin.getline(str,100);
    for(int i=0;i<strlen(str);i++)
    {
        if(isupper(str[i]))
            cout<<(char)tolower(str[i]);
        else
            cout<<str[i];
    }

    cout<<endl;

    return 0;
}
