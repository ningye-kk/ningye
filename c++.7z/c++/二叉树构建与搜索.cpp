#include <iostream>
#include <vector>

using namespace std;

vector<int> pre;
vector<int> in;

class Node
{
public:
    int data;
    Node* lchild;
    Node* rchild;
};

class Btree
{
public:
    vector<Node> vec;
    Btree()
    {
        int n;
        cin>>n;
        vec.resize(n);
        pre.resize(n);
        in.resize(n);

        for(int i=0;i<n;i++)
            cin>>pre[i];

        for(int j=0;j<n;j++)
            cin>>in[j];
    }

    Node* createTree(int preL,int preR,int inL,int inR)
    {
        if(preL>preR)
            return nullptr;
        Node* root=new Node;
        root->data=pre[preL];
        int i;

        for(i=inL;i<=inR;i++)
        {
            if(pre[preL]==in[i])
                break;
        }

        int llen=i-inL;

        root->lchild=createTree(preL+1,preL+llen,inL,i-1);
        root->rchild=createTree(preL+llen+1,preR,i+1,inR);
        return root;

    }

    Node* searchTree(Node* root,int key)
    {
        if(root==nullptr)
            return nullptr;
        searchTree(root->lchild,key);
        searchTree(root->rchild,key);

        if(key==root->data)
        {
            cout<<"���ҵ�"<<endl;
            return root;
        }
    }
};

int main()
{
    Btree tree;
    Node* root=tree.createTree(0,pre.size()-1,0,in.size()-1);
    Node* p=tree.searchTree(root,5);

    return 0;
}
