#include<iostream>

using namespace std;

void fun(int a[],int low,int length)
{
    if(low==length)
    {
        return;
    }
    fun(a,low+1,length);
    cout<<a[low]<<" ";
}

int main()
{
    int a[10];
    for(int i=0;i<10;i++)
        cin>>a[i];

    fun(a,0,10);

    return 0;
}
