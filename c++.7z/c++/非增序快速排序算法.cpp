//��������������㷨
#include <iostream>

using namespace std;

int partition(int a[],int low,int high){
    int pivot = a[low];
    while(low < high){
        while(low < high&&a[high] < pivot) high--;
        if(low <= high)
            a[low] = a[high];
        while(low < high&&a[low] > pivot) low++;
        if(low <= high)
            a[high] = a[low];
    }
    a[low] = pivot;
    return low;
}
void quickSort(int a[],int low,int high){
    if(low < high){
        int mid = partition(a,low,high);
        quickSort(a,low,mid-1);
        quickSort(a,mid+1,high);
    }
}


int main(){
    int a[10];
    for(int i = 0;i < 10;i++){
        cin>>a[i];
    }
    quickSort(a,0,9);
    for(int i = 0;i < 10;i++){
        cout<<a[i]<<" ";
    }
    cout<<endl;
    return 0;
}
