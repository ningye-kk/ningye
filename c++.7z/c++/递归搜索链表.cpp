#include <iostream>
#include <vector>

using namespace std;

class Node
{
    friend class linkList;
private:
    int data;
    Node* next;
public:
    Node():data(-1),next(nullptr){}
};

class linkList
{
public:
    vector<Node> L;
    linkList()
    {
        int n;
        cin>>n;
        L.resize(n);
        for(int i=0;i<L.size();i++)
        {
            cin>>L[i].data;
        }

        for(int i=0;i<L.size()-1;i++)
        {
            L[i].next=&L[i+1];
        }

        L[L.size()-1].next=nullptr;
    }

    Node* searchList(int k,int low)
    {
        if(L[low].data==k)
        {
            cout<<low<<endl;
            return &L[low];
        }
        if(low==L.size())
            return nullptr;
        Node* a=searchList(k,low+1);
        return a;
    }
};

int main()
{
    linkList lis;
    int k;
    cin>>k;
    lis.searchList(k,0);
    return 0;
}
