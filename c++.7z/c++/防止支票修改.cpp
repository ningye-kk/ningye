#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;

int main()
{
    float money;
    cin>>money;

    cout.width(8);
    cout.fill('*');
    cout<<fixed<<setprecision(2)<<money<<endl;
    return 0;
}

