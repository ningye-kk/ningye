#include <iostream>
#include <bitset>
#include <cmath>

using namespace std;

bitset<1024> a;

void fun(int m)
{
    for(int i=2;i<sqrt((double)m);i++)
    {
        if(a[i]==0)
        {
            for(int j=i*i;j<=m;j+=i)
            {
                a[j]=1;
            }
        }
    }

    for(int i=2;i<=1023;i++)
    {
        if(a[i]==0)
            cout<<i<<" ";
    }
    cout<<endl;
}

void zys(int n)
{
    bool flag=false;
    for(int i=0;i<=1023;i++)
    {
        if(a[i]==0&&i==n)
        {
            flag=true;
            cout<<n<<"������"<<endl;
            return;
        }
    }

    if(flag==false)
        cout<<n<<"��������"<<endl;
    int i=2;
    cout<<n<<"��������Ϊ:"<<endl;
    for(;i<=1023;i++)
    {
        if(a[i]==0&&n%i==0&&n!=0)
        {
            n/=i;
            cout<<i<<" ";
            i=1;
        }
    }
    cout<<endl;
}

int main()
{
    fun(1023);
    int m;
    cin>>m;
    zys(m);
    return 0;
}

