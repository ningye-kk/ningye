#include <iostream>
#include <algorithm>

using namespace std;

const int maxn = 100;

struct inteval{
    int x,y;
}I[maxn];

bool cmp(inteval a,inteval b){
    if(a.x!=b.x)return a.x>b.x;
    else return a.y<b.y;
}

int main(){
    int n;
    cout<<"����������ܸ���"<<endl;
    cin>>n;
    cout<<"������������Ҷ˵�"<<endl;
    for(int i = 0;i < n;i++){
        cin>>I[i].x>>I[i].y;
    }
    sort(I,I+n,cmp);
    int latex = I[0].x;
    int num = 0;
    for(int i = 1;i < n;i++){
        if(I[i].x<latex)
        {
            latex = I[i].x;
            num++;
        }
    }
    return 0;
}
