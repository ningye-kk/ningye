#include <iostream>

using namespace std;

const int maxn = 11;
int p[maxn], hashTable[maxn], n;

void genera_n(int index){
    if(index == n+1){
        for(int i = 1;i <= n;i++){
            cout<<" "<<p[i];
        }
        cout<<endl;
        return;
    }

    for(int x = 1;x <= n;x++){
        if(hashTable[x]==0){
            p[index] = x;
            hashTable[x] = x;
            genera_n(index+1);
            hashTable[x] = 0;
        }
    }
}

int main(){
    cin>>n;
    genera_n(1);
    return 0;
}
