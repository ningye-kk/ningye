#include <iostream>
#include <string>

using namespace std;

void reversePrint(string::iterator itb,string::iterator ite)
{
    if(itb==ite)
    {
       return;
    }
    reversePrint(itb+1,ite);
    cout<<*itb;
}

int main()
{
    string s;
    cin>>s;

    reversePrint(s.begin(),s.end());

    return 0;
}
