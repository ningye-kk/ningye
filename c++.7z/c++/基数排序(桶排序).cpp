#include <iostream>
#include <array>
#include <cstring>

using namespace std;

const int maxN=100;
const int N=10;

array<int,N> a;
array<array<int,10>,maxN>  p;


void initial()
{
    for(int i=0;i<10;i++)
    {
        for(int j=0;j<maxN;j++)
            p[i][j]=0;
    }
}

void write()
{
    int k=0;
    for(int i=0;i<10;i++)
    {
        for(int j=0;j<maxN;j++)
        {
            if(p[i][j]!=0)
            {
                a[k++]=p[i][j];
            }
        }
    }
}

void print()
{
    for(int i=0;i<N;i++)
        cout<<a[i]<<" ";
    cout<<endl;
}

void bucketSort()
{
    initial();

    int k=0;
    for(int i=0;i<N;i++)
    {
        int temp=a[i]%10;
        p[temp][k++]=a[i];
    }

    write();

    initial();

    k=0;
    for(int i=0;i<N;i++)
    {
        int temp=a[i]%100/10;
        p[temp][k++]=a[i];
    }

    write();

    print();
}

int main()
{
    for(int i=0;i<N;i++)
        cin>>a[i];

    bucketSort();

    return 0;
}
