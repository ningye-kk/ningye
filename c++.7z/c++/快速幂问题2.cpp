#include <iostream>

using namespace std;

typedef long long LL;

LL binaryPow(LL a,LL b,LL m){
    LL ans = 1;
    while(b > 0){
        if(b & 1){
            ans = ans * a;
        }
        a = a * a;
        b = b >> 1;
    }
    return ans%m;
}

int main(){
    cout<<binaryPow(2,10,5)<<endl;
    return 0;
}
