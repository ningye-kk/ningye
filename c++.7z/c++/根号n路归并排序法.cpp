#include <iostream>
#include <cmath>

using namespace std;

template <class T>
void mergeSort(T a[],int left,int right){
    if(left < right){
        int len =(int)sqrt(right - left + 1);
        for(int i = 0;i < len;i++){
            mergeSort(a,left+i*len,left+(i+1)*len-1);
        }
        //�ϲ�������Ӵ������û�У����޲�����
        mergeSort(a,left+len*len,right);
        mergeAll(a,left,right);
    }
}

template <class T>
void mergeAll(T a[],int left,int right){
    int len =(int)sqrt(right - left + 1);
    while(len <= right){
        for(int i = 0;i < right;i += len){
            merge1(a,min(right,left+i*2),min(right,left+2*i+len-1),min(right,left+2*i+2*len-1));
        }
        len *= 2;
    }
}

template <class T>
void merge1(T a[],int left,int mid,int right){
    int len = right - left + 1;
    int b[len+1];
    int i = left,j = mid + 1,k = 0;
    while(i <= mid && j <= right){
        if(a[i] <= a[j]){
            b[k++] = a[i];
            i++;
        }
        else{
            b[k++] = a[j];
            j++;
        }
    }
    while(i <= mid) b[k++] = a[i++];
    while(j <= right) b[k++] = a[j++];
    for(i = 0;i <= k;i++){
        a[left+i] = b[i];
    }
}

int main(){
    //��ʵ����
    return 0;
}
