#include <iostream>
using namespace std;

template <class T>
int binarySearch(T a[],int left,int right,const T& x,int &i,int &j){
    int middle;
    while(left <= right){
        middle = (left + right) / 2;
        if(x == a[middle]){
            i = j = middle;
            return 1;
        }
        else if(x < a[middle]){
            right = middle - 1;
        }
        else{
            left = middle + 1;
        }
    }
    i = right;
    j = left;
    return 0;
}

int main(){
    int x,y;
    int a[10];
    int key;
    cin>>key;
    for(int i = 0;i < 10;i++){
        cin>>a[i];
    }
    binarySearch(a,0,9,key,x,y);
    cout<<x<<" "<<y<<endl;
    return 0;
}
