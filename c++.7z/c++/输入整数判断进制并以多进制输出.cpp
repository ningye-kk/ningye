#include <iostream>
#include <iomanip>

using namespace std;

int main()
{
    char x[10];
    char* z;
    cin.getline(x,10);
    int y;
    int num;

    if(x[0]!='0')
    {
        cout<<"ʮ������"<<endl;
        num=10;
    }
    else
    {
        if(x[1]=='x')
        {
            cout<<"ʮ��������"<<endl;
            num=16;
        }
        else
        {
            cout<<"�˽�����"<<endl;
            num=8;
        }
    }

    y=strtol(x,&z,num);


    cout<<dec<<y<<'\t'<<oct<<y<<'\t'<<hex<<y<<'\t'<<endl;

    return 0;
}
