#include <iostream>
#include <algorithm>
#include <array>
#include <iterator>
#include <vector>
#include <fstream>
#include <list>
#include <cstring>
#include <iomanip>

using namespace std;

void insert_sort(int a[],int n)
{
    if(n==0)
        return;
    else
    {
        insert_sort(a,n-1);
        int temp=a[n-1];
        int i;
        for(i=n-1;i>0&&temp<a[i-1];i--)
            a[i]=a[i-1];
        a[i]=temp;
    }
}

int main()
{
    int a[10];
    for(int i=0;i<10;i++)
        cin>>a[i];

    insert_sort(a,10);

    for(int i=0;i<10;i++)
        cout<<a[i]<<" ";
    return 0;
}
