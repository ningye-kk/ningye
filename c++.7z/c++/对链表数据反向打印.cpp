#include <iostream>
#include <vector>

using namespace std;

class Node
{
    friend class linkList;
private:
    int data;
    Node* next;
public:
    Node():data(-1),next(nullptr)
    {}
};

class linkList
{
public:
    vector<Node> L;
    linkList()
    {
        int n;
        cin>>n;
        L.resize(n);
        for(int i=0;i<L.size();i++)
        {
            cin>>L[i].data;
        }

        for(int i=0;i<L.size()-1;i++)
        {
            L[i].next=&L[i+1];
        }

        L[L.size()-1].next=nullptr;
    }

    void printListBackward(int low,int high)
    {
        if(low==L.size())
            return;
        printListBackward(low+1,high);
        high=L.size()-1;
        if(low==high)
        {
            cout<<L[high].data<<" ";
            L.pop_back();
        }
    }
};




int main()
{
    linkList lis;
    lis.printListBackward(0,lis.L.size()-1);
    return 0;
}
