#include <iostream>

using namespace std;

const int maxn = 20;

int count = 0;
int n;
int q[maxn] = {0};
int hashTable[maxn] = {0};

void n_Queen(int index){
    if(index == n+1){
        count++;
        return;
    }

    for(int x = 1;x <= n;x++){
        if(hashTable[x] == false){
            bool flag = true;
            for(int pre = 1;pre < index;pre++){
                if(abs(x-q[pre]) == abs(pre-index)){
                    flag = false;
                    break;
                }
            }

            if(flag){
                q[index] = x;
                hashTable[x] = true;
                n_Queen(index+1);
                hashTable[x] = false;
            }
        }
    }
}

int main(){
    cin>>n;
    n_Queen(1);
    cout<<count<<endl;
    return 0;
}
