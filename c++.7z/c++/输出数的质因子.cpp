#include <iostream>
#include <bitset>
#include <cmath>
#include <cstring>

using namespace std;

bitset<1024> a;
int b[10];
int len=0;

void fun(int m)
{
    for(int i=2;i<sqrt((double)m);i++)
    {
        if(a[i]==0)
        {
            for(int j=i*i;j<=m;j+=i)
            {
                a[j]=1;
            }
        }
    }
}

void fun1(int n)
{
    int i=2;
    int temp=n;
    fun(n);
    for(;i<=n;i++)
    {
        if(a[i]==0)
        {
            while(temp)
            {
                if(temp%i==0)
                {
                    bool flag=false;
                    for(int k=0;k<=len;k++)
                    {
                        if(i==b[k])
                        {
                            flag=false;
                            break;
                        }
                        else
                        {
                            flag=true;
                        }
                    }

                    if(flag==true)
                        b[len++]=i;
                    temp/=i;
                    i=1;
                }
                break;

            }
        }
    }
}

void print()
{
    for(int i=0;i<len;i++)
        cout<<b[i]<<" ";
}

int main()
{
    fun1(54);
    print();
    return 0;
}
