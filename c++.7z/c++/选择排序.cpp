#include <iostream>
#include <algorithm>
#include <array>
#include <iterator>
#include <vector>
#include <fstream>
#include <list>
#include <cstring>
#include <iomanip>

using namespace std;

void choose_sort(int a[],int n)
{
    int small_index;
    for(int i=0;i<n-1;i++)
    {
        small_index=i;
        for(int j=i+1;j<n;j++)
        {
            if(a[small_index]>a[j])
                small_index=j;
        }
        int temp;
        temp=a[small_index];
        a[small_index]=a[i];
        a[i]=temp;
    }
}

int main()
{
    int a[10];
    for(int i=0;i<10;i++)
        cin>>a[i];

    choose_sort(a,10);

    for(int i=0;i<10;i++)
        cout<<a[i]<<" ";
    return 0;
}
