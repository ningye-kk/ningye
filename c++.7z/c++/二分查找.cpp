#include <iostream>
#include <array>
#include <algorithm>

using namespace std;

const int maxN=10;

int BinarySearch(array<int,maxN> a,int key,int low,int high)
{
    if(low>high)
        return -1;
    int mid=(high+low)/2;

    if(a[mid]>key)
    {
        BinarySearch(a,key,low,mid-1);
    }
    else if(a[mid]<key)
    {
        BinarySearch(a,key,mid+1,high);
    }
    else
        return mid;
}

int main()
{
    array<int,maxN> a;

    for(int i=0;i<maxN;i++)
        cin>>a[i];

    sort(a.begin(),a.end());

    for(int i=0;i<maxN;i++)
        cout<<a[i]<<" ";

    cout<<endl;

    int temp=BinarySearch(a,15,0,maxN-1);

    cout<<temp<<endl;

    return 0;
}
