#include <iostream>

using namespace std;

const int num=8;

int chess[num][num];
int queen[num];
int coun;

bool isOk(int i,int j)
{
    for(int temp=0;temp<i;temp++)
    {
        if(j==queen[temp])return false;
        if((j-queen[temp])==(i-temp))return false;
        if((j-queen[temp])+(i-temp)==0)return false;
    }
    return true;
}

void eightQueen(int i)
{
    for(int j=0;j<num;j++)
    {
        if(isOk(i,j))
        {
            queen[i]=j;
            if(i==num-1)
            {
                coun++;
                return;
            }
            eightQueen(i+1);
        }
    }

    queen[i]=0;
    return;
}

int main()
{
    eightQueen(0);
    cout<<coun<<endl;
    return 0;
}
